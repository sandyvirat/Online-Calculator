Online calculator:

Main.py: The online calculator is used to perform addition, subtraction, multiplication and division for integers, float numbers, fraction numbers and also for negative numbers. It is a flask based calculator. To run the application main.py you can either use Flask command or python -m switch with flask. Run the command prompt with "python main.py", if code doesn't contain any bugs it shows a url paste that url in web browser. Url should in format: "http: // some address/" operation? A=arg1&B=arg2.

 Test.py: The test.py file is used to check the work properly. If test.py runs successful then the code doesn't contain any bugs. Run the command prompt with "python test.py". The main.py and test.py should be in same folder otherwise (import main) function shows Error.


EX:        http://127.0.0.1:5000/div?A=4&B=2    =2.0
           http://127.0.0.1:5000/add?A=0&B=0    =0.0
           http://127.0.0.1:5000/sub?A=&B=      =None
